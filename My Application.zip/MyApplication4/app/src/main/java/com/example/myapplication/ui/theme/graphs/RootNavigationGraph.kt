package com.example.myapplication.ui.theme.graphs

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.myapplication.ui.theme.screens.HomeScreen
import com.google.accompanist.navigation.material.BottomSheetNavigator
import com.google.accompanist.navigation.material.ExperimentalMaterialNavigationApi
import com.google.accompanist.navigation.material.ModalBottomSheetLayout

@OptIn(ExperimentalMaterialNavigationApi::class)
@Composable
fun RootNavigationGraph(
    navController: NavHostController,
    bottomSheetNavigator: BottomSheetNavigator
) {
    ModalBottomSheetLayout(bottomSheetNavigator, sheetShape = RoundedCornerShape(topEnd = 16.dp, topStart = 16.dp)) {
        NavHost(
            navController = navController,
            route = Graph.ROOT,
            startDestination = Graph.AUTHENTICATION
        ) {

            authNavGraph(navController = navController)
            composable(route = Graph.HOME) {
                HomeScreen()
            }
            detailsNavGraph(navController)
        }
    }
}

object Graph {
    const val ROOT = "root_graph"
    const val AUTHENTICATION = "auth_graph"
    const val HOME = "home_graph"
    const val DETAILS = "details_graph"
}